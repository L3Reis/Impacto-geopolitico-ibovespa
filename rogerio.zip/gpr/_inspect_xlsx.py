﻿import sys
path = '/home/rogerio/mestrado_gpr/base_mfgarch_completa.xlsx'
out_lines = []

def log(s=''):
    out_lines.append(s)
    print(s)

try:
    import pandas as pd
except ImportError:
    import subprocess
    subprocess.check_call([sys.executable, '-m', 'pip', 'install', '-q', 'pandas', 'openpyxl'])
    import pandas as pd

log('=' * 80)
log('INSPECTION: base_mfgarch_completa.xlsx')
log('=' * 80)

xl = pd.ExcelFile(path)
sheet_names = xl.sheet_names
log(f'\n1. SHEET NAMES ({len(sheet_names)}):')
for i, name in enumerate(sheet_names, 1):
    log(f'   {i}. {repr(name)}')

TARGET_COLS = ['ret_ibov', 'log_gpr_global']

for sheet in sheet_names:
    log('\n' + '-' * 80)
    log(f'SHEET: {repr(sheet)}')
    log('-' * 80)
    df = pd.read_excel(path, sheet_name=sheet)
    log(f'Shape: {df.shape[0]} rows x {df.shape[1]} columns')
    log(f'\nColumns ({len(df.columns)}):')
    for j, c in enumerate(df.columns, 1):
        log(f'   {j}. {repr(c)} (dtype: {df[c].dtype})')

    log('\n--- First 5 rows ---')
    log(df.head(5).to_string())

    log('\n--- Last 5 rows ---')
    log(df.tail(5).to_string())

    date_candidates = []
    for c in df.columns:
        cn = str(c).lower()
        if 'date' in cn or 'data' in cn or cn in ('dt', 'time', 'periodo', 'period'):
            date_candidates.append(c)
        elif pd.api.types.is_datetime64_any_dtype(df[c]):
            date_candidates.append(c)
        else:
            sample = df[c].dropna().head(20)
            if len(sample) > 0:
                try:
                    parsed = pd.to_datetime(sample, errors='coerce')
                    if parsed.notna().mean() > 0.8:
                        date_candidates.append(c)
                except Exception:
                    pass

    log(f'\nLikely date column(s): {date_candidates if date_candidates else "None detected"}')

    for tcol in TARGET_COLS:
        log(f'\n>>> Column check: {tcol}')
        if tcol not in df.columns:
            matches = [c for c in df.columns if str(c).strip().lower() == tcol.lower()]
            if matches:
                tcol_actual = matches[0]
                log(f'    Found as: {repr(tcol_actual)}')
                col = df[tcol_actual]
            else:
                log('    NOT FOUND in this sheet')
                continue
        else:
            col = df[tcol]
            tcol_actual = tcol

        n = len(col)
        n_miss = col.isna().sum()
        n_valid = col.notna().sum()
        log(f'    Non-missing: {n_valid} / {n} ({100*n_valid/n:.2f}% valid)')
        log(f'    Missing: {n_miss} ({100*n_miss/n:.2f}%)')

        if n_valid > 0:
            log(f'    min={col.min()}, max={col.max()}, mean={col.mean():.6f}')

        date_col = date_candidates[0] if date_candidates else None
        if date_col is None:
            for c in df.columns:
                if df[c].dtype == object or pd.api.types.is_datetime64_any_dtype(df[c]):
                    try:
                        d = pd.to_datetime(df[c], errors='coerce')
                        if d.notna().sum() > n * 0.5:
                            date_col = c
                            break
                    except Exception:
                        pass

        if date_col is not None:
            log(f'    Date column used for frequency: {repr(date_col)}')
            dates = pd.to_datetime(df[date_col], errors='coerce')
            valid_mask = col.notna() & dates.notna()
            d_valid = dates[valid_mask].sort_values()
            if len(d_valid) >= 2:
                diffs = d_valid.diff().dropna()
                mode_diff = diffs.mode()
                log(f'    Date range (where {tcol_actual} valid): {d_valid.min()} to {d_valid.max()}')
                log(f'    Observations with valid date+value: {len(d_valid)}')
                log(f'    Median interval: {diffs.median()}')
                if len(mode_diff) > 0:
                    log(f'    Mode interval: {mode_diff.iloc[0]}')
                med_days = diffs.median().total_seconds() / 86400
                if 0.9 <= med_days <= 1.1:
                    freq_label = '~daily'
                elif 4 <= med_days <= 8:
                    freq_label = '~weekly'
                elif 25 <= med_days <= 35:
                    freq_label = '~monthly'
                elif 85 <= med_days <= 95:
                    freq_label = '~quarterly'
                else:
                    freq_label = f'~{med_days:.1f} days median'
                log(f'    Inferred frequency: {freq_label}')
                vc = diffs.value_counts().head(5)
                log('    Top interval counts:')
                for idx, cnt in vc.items():
                    log(f'      {idx}: {cnt}')
            else:
                log('    Not enough dated observations for frequency analysis')
        else:
            log('    No date column identified for frequency analysis on this sheet')

log('\n' + '=' * 80)
log('SUMMARY: ret_ibov and log_gpr_global across all sheets')
log('=' * 80)
for tcol in TARGET_COLS:
    log(f'\n{tcol}:')
    found_any = False
    for sheet in sheet_names:
        df = pd.read_excel(path, sheet_name=sheet)
        cols = [tcol] if tcol in df.columns else [c for c in df.columns if str(c).strip().lower() == tcol.lower()]
        if cols:
            found_any = True
            c = cols[0]
            log(f'  Sheet {repr(sheet)}: column {repr(c)}, missing={df[c].isna().sum()}/{len(df)}')
    if not found_any:
        log('  Not found in any sheet')

out_path = '/home/rogerio/mestrado_gpr/data_inspection.txt'
with open(out_path, 'w', encoding='utf-8') as f:
    f.write('\n'.join(out_lines))
log(f'\n\nSaved to: {out_path}')
