#!/usr/bin/env Rscript
# ------------------------------------------------------------------------------
# GARCH-MIDAS para retornos do IBOV com covariável log(GPR Global)
# Pacote: mfGARCH (Engle, Ghysels & Sohn, 2013)
#
# Uso:
#   Rscript garch_midas_ibov_gpr.R
#   Rscript garch_midas_ibov_gpr.R --arquivo base_mfgarch_completa.xlsx --k 12
# ------------------------------------------------------------------------------

suppressPackageStartupMessages({
  if (!requireNamespace("mfGARCH", quietly = TRUE)) {
    install.packages("mfGARCH", repos = "https://cloud.r-project.org")
  }
  if (!requireNamespace("readxl", quietly = TRUE)) {
    install.packages("readxl", repos = "https://cloud.r-project.org")
  }
  if (!requireNamespace("jsonlite", quietly = TRUE)) {
    install.packages("jsonlite", repos = "https://cloud.r-project.org")
  }
})

library(mfGARCH)
library(readxl)
library(jsonlite)

# ---------------------------------------------------------------------------
# Configuração padrão
# ---------------------------------------------------------------------------
DEFAULT_FILE   <- "base_mfgarch_completa.xlsx"
DEFAULT_SHEET  <- "Sheet1"
DEP_VAR        <- "ret_ibov"
COV_VAR        <- "log_gpr_global"
DATE_COL       <- "date"
LOW_FREQ_COL   <- "year_month"   # coluna de frequência baixa (mensal)
SCALE_RETURNS  <- 100            # estabilidade numérica (recomendação mfGARCH)
DEFAULT_K      <- 12L
DEFAULT_OUTPUT <- "resultados_garch_midas_r"

# ---------------------------------------------------------------------------
# Argumentos de linha de comando
# ---------------------------------------------------------------------------
parse_args <- function() {
  args <- commandArgs(trailingOnly = TRUE)
  out <- list(
    arquivo = DEFAULT_FILE,
    aba = DEFAULT_SHEET,
    k = DEFAULT_K,
    saida = DEFAULT_OUTPUT,
    pesos_nao_restritos = FALSE,
    gamma = FALSE
  )

  i <- 1
  while (i <= length(args)) {
    key <- args[i]
    if (key == "--arquivo" && i < length(args)) {
      out$arquivo <- args[i + 1]; i <- i + 2; next
    }
    if (key == "--aba" && i < length(args)) {
      out$aba <- args[i + 1]; i <- i + 2; next
    }
    if (key == "--k" && i < length(args)) {
      out$k <- as.integer(args[i + 1]); i <- i + 2; next
    }
    if (key == "--saida" && i < length(args)) {
      out$saida <- args[i + 1]; i <- i + 2; next
    }
    if (key == "--pesos-nao-restritos") {
      out$pesos_nao_restritos <- TRUE; i <- i + 1; next
    }
    if (key == "--gamma") {
      out$gamma <- TRUE; i <- i + 1; next
    }
    i <- i + 1
  }
  out
}

# ---------------------------------------------------------------------------
# Preparação dos dados
# ---------------------------------------------------------------------------
load_and_prepare <- function(
    filepath,
    sheet = DEFAULT_SHEET,
    dep_var = DEP_VAR,
    cov_var = COV_VAR,
    scale = SCALE_RETURNS
) {
  if (!file.exists(filepath)) {
    stop("Arquivo não encontrado: ", filepath)
  }

  df <- as.data.frame(readxl::read_excel(filepath, sheet = sheet))
  df[[DATE_COL]] <- as.Date(df[[DATE_COL]])
  df <- df[order(df[[DATE_COL]]), , drop = FALSE]
  rownames(df) <- NULL

  required <- c(DATE_COL, dep_var, cov_var)
  missing <- setdiff(required, names(df))
  if (length(missing) > 0) {
    stop("Colunas ausentes na planilha: ", paste(missing, collapse = ", "))
  }

  df <- df[complete.cases(df[, c(dep_var, cov_var)]), , drop = FALSE]

  # mfGARCH recomenda retornos x 100
  df$y <- df[[dep_var]] * scale
  df$x <- df[[cov_var]]

  # Coluna de frequência baixa (mensal)
  if (LOW_FREQ_COL %in% names(df)) {
    df$low_freq <- as.character(df[[LOW_FREQ_COL]])
  } else if ("month" %in% names(df)) {
    df$low_freq <- format(as.Date(df$month), "%Y-%m")
  } else {
    df$low_freq <- format(df[[DATE_COL]], "%Y-%m")
  }

  list(
    data = df,
    n_obs = nrow(df),
    n_months = length(unique(df$low_freq)),
    date_min = min(df[[DATE_COL]]),
    date_max = max(df[[DATE_COL]])
  )
}

# ---------------------------------------------------------------------------
# Estimação
# ---------------------------------------------------------------------------
fit_garch_midas <- function(
    df,
    k = DEFAULT_K,
    weighting = "beta.restricted",
    gamma = FALSE
) {
  fit_mfgarch(
    data = df,
    y = "y",
    x = "x",
    K = k,
    low.freq = "low_freq",
    var.ratio.freq = "low_freq",
    gamma = gamma,
    weighting = weighting,
    multi.start = FALSE
  )
}

# ---------------------------------------------------------------------------
# Resumo no terminal
# ---------------------------------------------------------------------------
print_summary <- function(fit, cov_var = COV_VAR, scale = SCALE_RETURNS) {
  cat("\n", strrep("=", 60), "\n", sep = "")
  cat("GARCH-MIDAS (mfGARCH) — ret_ibov ~ log_gpr_global\n")
  cat(strrep("=", 60), "\n", sep = "")

  cat("Convergência:", ifelse(fit$optim$convergence == 0, "Sim", "Não"), "\n")
  cat("Mensagem:", fit$optim$message, "\n")
  cat("Observações:", nrow(fit$df.fitted), "\n")
  cat("Log-verossimilhança:", round(fit$llh, 4), "\n")
  cat("BIC:", round(fit$bic, 4), "\n")
  cat("K:", fit$K, "\n")
  cat("Pesos:", fit$weighting.scheme, "\n")
  cat("Variance ratio:", round(fit$variance.ratio, 4), "\n")

  cat("\nParâmetros estimados (mfGARCH):\n")
  print(fit$broom.mgarch)

  theta_row <- fit$broom.mgarch[grepl("theta", fit$broom.mgarch$term, ignore.case = TRUE), , drop = FALSE]
  if (nrow(theta_row) > 0) {
    cat("\nSignificância de theta:\n")
    cat(sprintf(
      "  theta = %.6f | EP = %.6f | p-valor = %.6g\n",
      theta_row$estimate, theta_row$rob.std.err, theta_row$p.value
    ))
    if (theta_row$estimate < 0) {
      cat("  -> Maior GPR (log) associa-se a menor volatilidade de longo prazo.\n")
    } else if (theta_row$estimate > 0) {
      cat("  -> Maior GPR (log) associa-se a maior volatilidade de longo prazo.\n")
    }
  }

  cat(strrep("=", 60), "\n\n", sep = "")
}

# ---------------------------------------------------------------------------
# Saídas
# ---------------------------------------------------------------------------
save_outputs <- function(fit, df, output_dir, scale = SCALE_RETURNS) {
  dir.create(output_dir, recursive = TRUE, showWarnings = FALSE)
  inv_scale <- 1 / scale

  # JSON
  params_list <- setNames(as.list(fit$par), names(fit$par))
  summary_json <- list(
    modelo = "GARCH-MIDAS",
    pacote = "mfGARCH",
    variavel_dependente = DEP_VAR,
    variavel_independente = COV_VAR,
    params = params_list,
    broom_mgarch = fit$broom.mgarch,
    log_likelihood = unname(fit$llh),
    bic = unname(fit$bic),
    K = fit$K,
    weighting = fit$weighting.scheme,
    variance_ratio = unname(fit$variance.ratio),
    n_obs = nrow(fit$df.fitted),
    converged = fit$optim$convergence == 0,
    message = fit$optim$message
  )
  write_json(
    summary_json,
    file.path(output_dir, "garch_midas_resultados.json"),
    pretty = TRUE,
    auto_unbox = TRUE,
    dataframe = "rows"
  )

  # Série temporal (reconvertida à escala original)
  fitted <- fit$df.fitted
  series_df <- data.frame(
    date = fitted$date,
    ret_ibov = fitted$y * inv_scale,
    sigma2 = (fitted$tau * fitted$g) * inv_scale^2,
    sqrt_sigma2 = sqrt(fitted$tau * fitted$g) * inv_scale,
    tau_long_term = fitted$tau * inv_scale^2,
    g_short_term = fitted$g,
    residuos_padronizados = fitted$residuals
  )
  write.csv(
    series_df,
    file.path(output_dir, "garch_midas_series.csv"),
    row.names = FALSE
  )

  # Covariável mensal
  monthly_cov <- aggregate(
    x ~ low_freq,
    data = df[, c("low_freq", "x")],
    FUN = function(v) v[1]
  )
  names(monthly_cov) <- c("year_month", COV_VAR)
  write.csv(
    monthly_cov,
    file.path(output_dir, "covariavel_mensal.csv"),
    row.names = FALSE
  )

  # Gráfico: decomposição da volatilidade
  png(file.path(output_dir, "volatilidade_decomposicao.png"), width = 1200, height = 1000, res = 150)
  op <- par(mfrow = c(3, 1), mar = c(4, 4, 2, 1))
  on.exit(par(op), add = TRUE)

  vol_total <- sqrt(fitted$tau * fitted$g) * inv_scale
  vol_g <- sqrt(fitted$g)
  vol_tau <- sqrt(fitted$tau) * inv_scale

  plot(fitted$date, vol_total, type = "l", col = "black", lwd = 0.8,
       xlab = "", ylab = "Vol. total", main = "GARCH-MIDAS (mfGARCH): IBOV com log(GPR Global)")
  plot(fitted$date, vol_g, type = "l", col = "steelblue", lwd = 0.8,
       xlab = "", ylab = "Vol. curto prazo")
  plot(fitted$date, vol_tau, type = "l", col = "darkred", lwd = 0.8,
       xlab = "Data", ylab = "Vol. longo prazo")
  dev.off()

  # Gráfico: resíduos padronizados
  png(file.path(output_dir, "residuos_padronizados.png"), width = 1200, height = 400, res = 150)
  plot(fitted$date, fitted$residuals, type = "l", col = "gray40", lwd = 0.6,
       main = "Resíduos padronizados", xlab = "Data", ylab = expression(epsilon))
  abline(h = 0, col = "black")
  dev.off()

  # Gráfico: esquema de pesos MIDAS
  png(file.path(output_dir, "pesos_midas.png"), width = 800, height = 500, res = 150)
  plot_weighting_scheme(fit)
  dev.off()

  cat("Resultados salvos em:", normalizePath(output_dir), "\n")
}

# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------
main <- function() {
  args <- parse_args()

  cat("Carregando:", args$arquivo, "\n")
  prep <- load_and_prepare(args$arquivo, sheet = args$aba)
  df <- prep$data

  cat("Observações diárias:", prep$n_obs, "\n")
  cat("Meses na covariável:", prep$n_months, "\n")
  cat("Período:", as.character(prep$date_min), "a", as.character(prep$date_max), "\n")

  weighting <- if (args$pesos_nao_restritos) "beta.unrestricted" else "beta.restricted"

  fit <- fit_garch_midas(
    df = df,
    k = args$k,
    weighting = weighting,
    gamma = args$gamma
  )

  print_summary(fit)
  save_outputs(fit, df, args$saida)
}

main()
