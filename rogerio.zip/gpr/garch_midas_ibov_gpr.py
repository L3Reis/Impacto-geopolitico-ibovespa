#!/usr/bin/env python3
"""
GARCH-MIDAS para retornos do IBOV com covariável log(GPR Global).

Modelo (Engle, Ghysels & Sohn, 2013):
    r_t = mu + sqrt(g_t * tau_t) * epsilon_t,  epsilon_t ~ N(0, 1)
    g_t = (1 - alpha - beta) + alpha * (r_{t-1} - mu)^2 / tau_{t-1} + beta * g_{t-1}
    log(tau_t) = m + theta * sum_{k=1}^{K} phi_k(omega) * X_{t-k}

Onde X é a variável de baixa frequência (mensal) log_gpr_global.

Uso:
    python garch_midas_ibov_gpr.py
    python garch_midas_ibov_gpr.py --arquivo base_mfgarch_completa.xlsx --k 12
"""

from __future__ import annotations

import argparse
import json
import warnings
from dataclasses import dataclass
from pathlib import Path
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy.optimize import minimize

warnings.filterwarnings("ignore", category=RuntimeWarning)

# ---------------------------------------------------------------------------
# Configuração padrão
# ---------------------------------------------------------------------------
DEFAULT_FILE = "base_mfgarch_completa.xlsx"
DEFAULT_SHEET = "Sheet1"
DEP_VAR = "ret_ibov"
COV_VAR = "log_gpr_global"
DATE_COL = "date"
MONTH_COL = "month"
SCALE_RETURNS = 100.0  # estabilidade numérica (padrão mfGARCH)
DEFAULT_K = 12


@dataclass
class GarchMidasResult:
    params: dict[str, float]
    log_likelihood: float
    aic: float
    bic: float
    n_obs: int
    converged: bool
    message: str
    tau: np.ndarray
    g: np.ndarray
    sigma2: np.ndarray
    residuals: np.ndarray
    dates: pd.DatetimeIndex
    monthly_covariate: pd.Series


# ---------------------------------------------------------------------------
# Pesos Beta-MIDAS
# ---------------------------------------------------------------------------
def beta_weights(k: int, w1: float = 1.0, w2: float | None = None) -> np.ndarray:
    """Pesos Beta restritos (w1=1) ou não restritos."""
    if w2 is None:
        w2 = w1
    j = np.arange(1, k + 1, dtype=float)
    x = j / (k + 1.0)
    weights = (x ** (w1 - 1.0)) * ((1.0 - x) ** (w2 - 1.0))
    weights /= weights.sum()
    return weights


def midas_tau(
    x_monthly: np.ndarray,
    month_idx_daily: np.ndarray,
    m: float,
    theta: float,
    weights: np.ndarray,
) -> np.ndarray:
    """Calcula tau_t para cada observação diária."""
    n_days = len(month_idx_daily)
    k = len(weights)
    n_months = len(x_monthly)
    log_tau = np.full(n_days, m, dtype=float)

    for lag in range(k):
        month_lag = month_idx_daily - (lag + 1)
        valid = month_lag >= 0
        x_lagged = np.zeros(n_days, dtype=float)
        x_lagged[valid] = x_monthly[month_lag[valid]]
        log_tau += theta * weights[lag] * x_lagged

    tau = np.exp(log_tau)
    tau = np.clip(tau, 1e-12, None)
    return tau


def garch_short_term(
    returns: np.ndarray,
    tau: np.ndarray,
    mu: float,
    alpha: float,
    beta: float,
) -> np.ndarray:
    """Componente de curto prazo g_t."""
    n = len(returns)
    g = np.ones(n, dtype=float)
    eps = returns - mu

    for t in range(1, n):
        g[t] = (1.0 - alpha - beta) + alpha * (eps[t - 1] ** 2) / tau[t - 1] + beta * g[t - 1]
        g[t] = max(g[t], 1e-12)

    return g


def negative_log_likelihood(
    params: np.ndarray,
    returns: np.ndarray,
    x_monthly: np.ndarray,
    month_idx_daily: np.ndarray,
    k: int,
    restricted_weights: bool,
) -> float:
    """Log-verossimilhança negativa (Normal)."""
    mu, alpha, beta, m, theta = params[:5]
    if restricted_weights:
        w2 = params[5]
        weights = beta_weights(k, w1=1.0, w2=w2)
    else:
        w1, w2 = params[5], params[6]
        weights = beta_weights(k, w1=w1, w2=w2)

    if alpha < 0 or beta < 0 or alpha + beta >= 1:
        return 1e12
    if w2 <= 0 or (not restricted_weights and (params[5] <= 0 or params[6] <= 0)):
        return 1e12

    tau = midas_tau(x_monthly, month_idx_daily, m, theta, weights)
    g = garch_short_term(returns, tau, mu, alpha, beta)
    sigma2 = g * tau
    eps2 = (returns - mu) ** 2

    ll = -0.5 * np.sum(np.log(2 * np.pi) + np.log(sigma2) + eps2 / sigma2)
    return -ll


# ---------------------------------------------------------------------------
# Preparação dos dados
# ---------------------------------------------------------------------------
def load_and_prepare(
    filepath: Path,
    sheet: str = DEFAULT_SHEET,
    dep_var: str = DEP_VAR,
    cov_var: str = COV_VAR,
    scale: float = SCALE_RETURNS,
) -> tuple[np.ndarray, np.ndarray, np.ndarray, pd.DatetimeIndex, pd.Series]:
    """Carrega Excel e prepara retornos diários + covariável mensal."""
    df = pd.read_excel(filepath, sheet_name=sheet)
    df[DATE_COL] = pd.to_datetime(df[DATE_COL])
    df = df.sort_values(DATE_COL).reset_index(drop=True)

    required = {DATE_COL, dep_var, cov_var}
    missing = required - set(df.columns)
    if missing:
        raise ValueError(f"Colunas ausentes na planilha: {sorted(missing)}")

    df = df.dropna(subset=[dep_var, cov_var]).copy()
    df[dep_var] = df[dep_var] * scale

    if MONTH_COL in df.columns:
        df["_month_key"] = pd.to_datetime(df[MONTH_COL]).dt.to_period("M")
    elif "year_month" in df.columns:
        df["_month_key"] = pd.PeriodIndex(df["year_month"], freq="M")
    else:
        df["_month_key"] = df[DATE_COL].dt.to_period("M")

    monthly = (
        df.groupby("_month_key", sort=True)[cov_var]
        .first()
        .reset_index()
    )
    monthly["_month_key"] = monthly["_month_key"].astype(str)
    month_to_idx = {m: i for i, m in enumerate(monthly["_month_key"])}

    df["_month_str"] = df["_month_key"].astype(str)
    month_idx = df["_month_str"].map(month_to_idx).to_numpy()

    if np.any(pd.isna(month_idx)):
        raise ValueError("Falha ao mapear observações diárias para meses.")

    returns = df[dep_var].to_numpy(dtype=float)
    x_monthly = monthly[cov_var].to_numpy(dtype=float)
    dates = pd.DatetimeIndex(df[DATE_COL])
    monthly_series = monthly.set_index("_month_key")[cov_var]

    return returns, x_monthly, month_idx.astype(int), dates, monthly_series


# ---------------------------------------------------------------------------
# Estimação
# ---------------------------------------------------------------------------
def fit_garch_midas(
    returns: np.ndarray,
    x_monthly: np.ndarray,
    month_idx_daily: np.ndarray,
    k: int = DEFAULT_K,
    restricted_weights: bool = True,
) -> GarchMidasResult:
    """Estima GARCH-MIDAS por máxima verossimilhança."""
    n = len(returns)
    if n < k + 50:
        raise ValueError(f"Poucas observações ({n}) para K={k}.")

    # Valores iniciais
    mu0 = float(np.mean(returns))
    var0 = float(np.var(returns))
    x0 = np.array([mu0, 0.05, 0.90, np.log(var0), -0.01, 5.0])

    bounds = [
        (None, None),  # mu
        (1e-8, 0.999),  # alpha
        (1e-8, 0.999),  # beta
        (None, None),  # m
        (None, None),  # theta
        (1e-4, 50.0),  # w2 (ou w1)
    ]
    if not restricted_weights:
        x0 = np.array([mu0, 0.05, 0.90, np.log(var0), -0.01, 1.0, 5.0])
        bounds = bounds + [(1e-4, 50.0)]

    def objective(p: np.ndarray) -> float:
        return negative_log_likelihood(
            p, returns, x_monthly, month_idx_daily, k, restricted_weights
        )

    result = minimize(
        objective,
        x0,
        method="L-BFGS-B",
        bounds=bounds,
        options={"maxiter": 5000, "ftol": 1e-9},
    )

    mu, alpha, beta, m, theta = result.x[:5]
    if restricted_weights:
        w2 = result.x[5]
        weights = beta_weights(k, w1=1.0, w2=w2)
        param_names = ["mu", "alpha", "beta", "m", "theta", "w2"]
        param_values = list(result.x[:6])
    else:
        w1, w2 = result.x[5], result.x[6]
        weights = beta_weights(k, w1=w1, w2=w2)
        param_names = ["mu", "alpha", "beta", "m", "theta", "w1", "w2"]
        param_values = list(result.x[:7])

    tau = midas_tau(x_monthly, month_idx_daily, m, theta, weights)
    g = garch_short_term(returns, tau, mu, alpha, beta)
    sigma2 = g * tau
    residuals = (returns - mu) / np.sqrt(sigma2)

    n_params = len(param_values)
    log_lik = -result.fun
    aic = 2 * n_params - 2 * log_lik
    bic = n_params * np.log(n) - 2 * log_lik

    params_dict = dict(zip(param_names, [float(v) for v in param_values]))
    params_dict["K"] = k
    params_dict["restricted_weights"] = restricted_weights

    return GarchMidasResult(
        params=params_dict,
        log_likelihood=float(log_lik),
        aic=float(aic),
        bic=float(bic),
        n_obs=n,
        converged=bool(result.success),
        message=str(result.message),
        tau=tau,
        g=g,
        sigma2=sigma2,
        residuals=residuals,
        dates=pd.DatetimeIndex([]),  # preenchido depois
        monthly_covariate=pd.Series(dtype=float),
    )


# ---------------------------------------------------------------------------
# Saídas
# ---------------------------------------------------------------------------
def print_summary(result: GarchMidasResult, cov_var: str = COV_VAR) -> None:
    """Imprime resumo da estimação."""
    print("\n" + "=" * 60)
    print("GARCH-MIDAS — ret_ibov ~ log_gpr_global")
    print("=" * 60)
    print(f"Convergência: {'Sim' if result.converged else 'Não'}")
    print(f"Mensagem: {result.message}")
    print(f"Observações: {result.n_obs}")
    print(f"Log-verossimilhança: {result.log_likelihood:.4f}")
    print(f"AIC: {result.aic:.4f}")
    print(f"BIC: {result.bic:.4f}")
    print("\nParâmetros estimados:")
    for name, value in result.params.items():
        if isinstance(value, bool):
            print(f"  {name:22s}: {value}")
        elif name == "K":
            print(f"  {name:22s}: {int(value)}")
        else:
            print(f"  {name:22s}: {value: .6f}")

    persistence = result.params["alpha"] + result.params["beta"]
    print(f"\nPersistência GARCH (alpha + beta): {persistence:.6f}")

    var_ratio = np.mean(result.tau) / np.mean(result.sigma2)
    print(f"Proporção média tau/sigma² (componente longo): {var_ratio:.4f}")

    theta = result.params["theta"]
    print(f"\nEfeito de {cov_var} (theta): {theta:.6f}")
    if theta < 0:
        print("  -> Maior GPR (log) associa-se a menor volatilidade de longo prazo.")
    elif theta > 0:
        print("  -> Maior GPR (log) associa-se a maior volatilidade de longo prazo.")
    print("=" * 60 + "\n")


def save_outputs(
    result: GarchMidasResult,
    dates: pd.DatetimeIndex,
    monthly_cov: pd.Series,
    output_dir: Path,
    scale: float = SCALE_RETURNS,
) -> None:
    """Salva resultados, séries e gráficos."""
    output_dir.mkdir(parents=True, exist_ok=True)

    # JSON com parâmetros
    summary = {
        "modelo": "GARCH-MIDAS",
        "variavel_dependente": DEP_VAR,
        "variavel_independente": COV_VAR,
        "params": result.params,
        "log_likelihood": result.log_likelihood,
        "aic": result.aic,
        "bic": result.bic,
        "n_obs": result.n_obs,
        "converged": result.converged,
        "message": result.message,
    }
    with open(output_dir / "garch_midas_resultados.json", "w", encoding="utf-8") as f:
        json.dump(summary, f, indent=2, ensure_ascii=False)

    # Série temporal (volatilidades em escala original; retornos sem fator x100)
    inv_scale = 1.0 / scale
    series_df = pd.DataFrame(
        {
            DATE_COL: dates,
            DEP_VAR: (result.residuals * np.sqrt(result.sigma2) + result.params["mu"]) * inv_scale,
            "sigma2": result.sigma2 * (inv_scale ** 2),
            "sqrt_sigma2": np.sqrt(result.sigma2) * inv_scale,
            "tau_long_term": result.tau * (inv_scale ** 2),
            "g_short_term": result.g,
            "residuos_padronizados": result.residuals,
        }
    )
    series_df.to_csv(output_dir / "garch_midas_series.csv", index=False)
    monthly_cov.to_csv(output_dir / "covariavel_mensal.csv", header=[COV_VAR])

    # Gráfico 1: decomposição da volatilidade
    fig, axes = plt.subplots(3, 1, figsize=(12, 10), sharex=True)

    axes[0].plot(dates, np.sqrt(result.sigma2), color="black", linewidth=0.6, label=r"$\sqrt{\sigma^2_t}$")
    axes[0].set_ylabel("Vol. total")
    axes[0].legend(loc="upper right")
    axes[0].set_title("GARCH-MIDAS: IBOV com log(GPR Global)")

    axes[1].plot(dates, np.sqrt(result.g), color="steelblue", linewidth=0.6, label=r"$\sqrt{g_t}$ (curto prazo)")
    axes[1].set_ylabel("Vol. curto prazo")
    axes[1].legend(loc="upper right")

    axes[2].plot(dates, np.sqrt(result.tau), color="darkred", linewidth=0.6, label=r"$\sqrt{\tau_t}$ (longo prazo)")
    axes[2].set_ylabel("Vol. longo prazo")
    axes[2].set_xlabel("Data")
    axes[2].legend(loc="upper right")

    plt.tight_layout()
    fig.savefig(output_dir / "volatilidade_decomposicao.png", dpi=150)
    plt.close(fig)

    # Gráfico 2: resíduos padronizados
    fig, ax = plt.subplots(figsize=(12, 4))
    ax.plot(dates, result.residuals, color="gray", linewidth=0.5)
    ax.axhline(0, color="black", linewidth=0.8)
    ax.set_title("Resíduos padronizados")
    ax.set_xlabel("Data")
    plt.tight_layout()
    fig.savefig(output_dir / "residuos_padronizados.png", dpi=150)
    plt.close(fig)

    print(f"Resultados salvos em: {output_dir.resolve()}")


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------
def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Estima GARCH-MIDAS com ret_ibov e log_gpr_global."
    )
    parser.add_argument(
        "--arquivo",
        type=str,
        default=DEFAULT_FILE,
        help=f"Caminho do Excel (padrão: {DEFAULT_FILE})",
    )
    parser.add_argument(
        "--aba",
        type=str,
        default=DEFAULT_SHEET,
        help=f"Aba da planilha (padrão: {DEFAULT_SHEET})",
    )
    parser.add_argument(
        "--k",
        type=int,
        default=DEFAULT_K,
        help=f"Lags MIDAS mensais (padrão: {DEFAULT_K})",
    )
    parser.add_argument(
        "--saida",
        type=str,
        default="resultados_garch_midas",
        help="Diretório de saída",
    )
    parser.add_argument(
        "--pesos-nao-restritos",
        action="store_true",
        help="Usa pesos Beta não restritos (w1 e w2 livres)",
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    filepath = Path(args.arquivo)
    if not filepath.exists():
        raise FileNotFoundError(f"Arquivo não encontrado: {filepath}")

    print(f"Carregando: {filepath}")
    returns, x_monthly, month_idx, dates, monthly_cov = load_and_prepare(
        filepath, sheet=args.aba
    )
    print(f"Observações diárias: {len(returns)}")
    print(f"Meses na covariável: {len(x_monthly)}")
    print(f"Período: {dates.min().date()} a {dates.max().date()}")

    result = fit_garch_midas(
        returns,
        x_monthly,
        month_idx,
        k=args.k,
        restricted_weights=not args.pesos_nao_restritos,
    )
    result.dates = dates
    result.monthly_covariate = monthly_cov

    print_summary(result)
    save_outputs(result, dates, monthly_cov, Path(args.saida), scale=SCALE_RETURNS)


if __name__ == "__main__":
    main()
