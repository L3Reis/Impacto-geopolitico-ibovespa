﻿import json
from pathlib import Path

import numpy as np
from scipy import stats
from scipy.optimize import minimize

from garch_midas_ibov_gpr import (
    DEFAULT_FILE,
    load_and_prepare,
    negative_log_likelihood,
    fit_garch_midas,
)

K = 12
restricted = True


def nll_vec(params, returns, x_monthly, month_idx):
    return negative_log_likelihood(
        params, returns, x_monthly, month_idx, K, restricted
    )


def numerical_hessian(fun, x, eps=1e-5):
    x = np.asarray(x, dtype=float)
    n = x.size
    H = np.zeros((n, n), dtype=float)
    f0 = fun(x)
    for i in range(n):
        ei = np.zeros(n)
        ei[i] = eps
        f_ip = fun(x + ei)
        f_im = fun(x - ei)
        H[i, i] = (f_ip - 2.0 * f0 + f_im) / (eps ** 2)
        for j in range(i + 1, n):
            ej = np.zeros(n)
            ej[j] = eps
            f_pp = fun(x + ei + ej)
            f_pm = fun(x + ei - ej)
            f_mp = fun(x - ei + ej)
            f_mm = fun(x - ei - ej)
            hij = (f_pp - f_pm - f_mp + f_mm) / (4.0 * eps ** 2)
            H[i, j] = hij
            H[j, i] = hij
    return H


def fit_theta_zero(returns, x_monthly, month_idx):
    mu0 = float(np.mean(returns))
    var0 = float(np.var(returns))
    x0 = np.array([mu0, 0.05, 0.90, np.log(var0), 5.0])
    bounds = [
        (None, None),
        (1e-8, 0.999),
        (1e-8, 0.999),
        (None, None),
        (1e-4, 50.0),
    ]

    def objective(p):
        mu, alpha, beta, m, w2 = p
        full = np.array([mu, alpha, beta, m, 0.0, w2])
        return negative_log_likelihood(
            full, returns, x_monthly, month_idx, K, restricted
        )

    return minimize(
        objective,
        x0,
        method="L-BFGS-B",
        bounds=bounds,
        options={"maxiter": 5000, "ftol": 1e-9},
    )


filepath = Path(DEFAULT_FILE)
returns, x_monthly, month_idx, dates, _ = load_and_prepare(filepath)

with open("resultados_garch_midas/garch_midas_resultados.json", encoding="utf-8") as f:
    saved = json.load(f)

result_unr = fit_garch_midas(returns, x_monthly, month_idx, k=K, restricted_weights=restricted)
param_names = ["mu", "alpha", "beta", "m", "theta", "w2"]
mle = np.array([result_unr.params[n] for n in param_names], dtype=float)

ll_saved = float(saved["log_likelihood"])
ll_unr = float(result_unr.log_likelihood)

obj = lambda p: nll_vec(p, returns, x_monthly, month_idx)
H = numerical_hessian(obj, mle, eps=1e-5)

invertible = False
se = None
try:
    cov = np.linalg.inv(H)
    invertible = True
    se = np.sqrt(np.maximum(np.diag(cov), 0.0))
except np.linalg.LinAlgError:
    pass

theta_idx = 4
theta_hat = mle[theta_idx]
if se is not None:
    se_theta = se[theta_idx]
    t_theta = theta_hat / se_theta if se_theta > 0 else float("nan")
    p_theta = 2.0 * (1.0 - stats.norm.cdf(abs(t_theta)))
else:
    se_theta = t_theta = p_theta = float("nan")

res_restricted = fit_theta_zero(returns, x_monthly, month_idx)
ll_restricted = -float(res_restricted.fun)
lr_stat = 2.0 * (ll_unr - ll_restricted)
lr_p = float(stats.chi2.sf(lr_stat, df=1))

print("=== GARCH-MIDAS K=12 restricted Beta weights ===")
print("n_obs:", len(returns))
print("LL unrestricted saved:", ll_saved)
print("LL unrestricted refit:", ll_unr)
print("LL restricted theta=0:", ll_restricted)
print("--- theta Wald ---")
print("estimate:", theta_hat)
print("std_error:", se_theta)
print("t_stat:", t_theta)
print("p_value_two_sided_normal:", p_theta)
print("hessian_invertible:", invertible)
print("--- LR test theta=0 ---")
print("LR_stat:", lr_stat)
print("LR_p_value_chi2_df1:", lr_p)
print("restricted_converged:", res_restricted.success)
