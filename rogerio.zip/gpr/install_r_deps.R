# Dependências R para garch_midas_ibov_gpr.R
pkgs <- c("mfGARCH", "readxl", "jsonlite")
for (pkg in pkgs) {
  if (!requireNamespace(pkg, quietly = TRUE)) {
    install.packages(pkg, repos = "https://cloud.r-project.org")
  }
}
cat("Pacotes instalados:", paste(pkgs, collapse = ", "), "\n")
