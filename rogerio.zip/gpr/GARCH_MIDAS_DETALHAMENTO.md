# GARCH-MIDAS: detalhamento da aplicação em `garch_midas_ibov_gpr.py`

Este documento descreve a especificação teórica, o fluxo de implementação e os resultados da estimação do modelo **GARCH-MIDAS** (Engle, Ghysels & Sohn, 2013) aplicado aos retornos do IBOV com a covariável `log_gpr_global`, conforme implementado no script `garch_midas_ibov_gpr.py`.

---

## 1. Referência e objetivo

O modelo **GARCH-MIDAS** decompõe a volatilidade condicional em dois componentes multiplicativos:

| Componente | Símbolo | Frequência | Interpretação |
|------------|---------|------------|---------------|
| Curto prazo | \(g_t\) | Diária | Dinâmica GARCH clássica (choques recentes) |
| Longo prazo | \(\tau_t\) | Mensal (MIDAS) | Tendência de volatilidade explicada por covariável macro |

**Objetivo do script:** estimar como o **log do índice de Geopolitical Risk (GPR) Global** influencia a volatilidade de longo prazo dos retornos diários do IBOV.

**Referência:** Engle, R. F., Ghysels, E., & Sohn, B. (2013). *Stock Market Volatility and Macroeconomic Fundamentals*. Review of Economics and Statistics, 95(3), 776–797.

---

## 2. Especificação do modelo

### 2.1 Equação da média e variância condicional

Os retornos diários \(r_t\) seguem:

\[
r_t = \mu + \sqrt{g_t \cdot \tau_t}\,\varepsilon_t, \qquad \varepsilon_t \sim \mathcal{N}(0,1)
\]

A variância condicional total é:

\[
\sigma_t^2 = g_t \cdot \tau_t
\]

### 2.2 Componente de curto prazo (GARCH)

\[
g_t = (1 - \alpha - \beta) + \alpha \frac{(r_{t-1} - \mu)^2}{\tau_{t-1}} + \beta\, g_{t-1}
\]

| Parâmetro | Restrição | Papel |
|-----------|-----------|-------|
| \(\alpha\) | \(\alpha \geq 0\) | Sensibilidade ao choque recente |
| \(\beta\) | \(\beta \geq 0\) | Persistência da volatilidade de curto prazo |
| \(\alpha + \beta\) | \(< 1\) | Condição de estacionariedade |

No script, \(g_1 = 1\) (inicialização padrão) e \(g_t\) é recalculado iterativamente pela função `garch_short_term()`.

### 2.3 Componente de longo prazo (MIDAS)

\[
\log(\tau_t) = m + \theta \sum_{k=1}^{K} \phi_k(\omega_1, \omega_2)\, X_{t-k}
\]

\[
\tau_t = \exp\!\left(\log(\tau_t)\right)
\]

Onde:

- \(X_{t-k}\) = valor mensal de `log_gpr_global` defasado em \(k\) meses;
- \(K\) = número de lags mensais (padrão: **12**);
- \(\theta\) = elasticidade do GPR sobre a volatilidade de longo prazo;
- \(m\) = intercepto do componente longo prazo.

### 2.4 Pesos Beta-MIDAS

Os pesos \(\phi_k\) seguem a função Beta:

\[
\phi_k(\omega_1, \omega_2) = \frac{f\!\left(\frac{k}{K+1};\,\omega_1,\,\omega_2\right)}{\sum_{j=1}^{K} f\!\left(\frac{j}{K+1};\,\omega_1,\,\omega_2\right)}
\]

com densidade Beta:

\[
f(x;\,\omega_1,\,\omega_2) \propto x^{\omega_1 - 1}(1-x)^{\omega_2 - 1}
\]

**Configuração padrão do script:** pesos **Beta restritos** (\(\omega_1 = 1\) fixo; apenas \(\omega_2\) estimado). Isso corresponde ao argumento `restricted_weights=True` em `fit_garch_midas()`.

Implementação: função `beta_weights()`.

### 2.5 Função de verossimilhança

Sob normalidade dos resíduos padronizados:

\[
\mathcal{L} = -\frac{1}{2}\sum_{t=1}^{T}\left[\ln(2\pi) + \ln(\sigma_t^2) + \frac{(r_t - \mu)^2}{\sigma_t^2}\right]
\]

O script **maximiza** \(\mathcal{L}\) minimizando sua versão negativa em `negative_log_likelihood()`.

---

## 3. Dados utilizados

### 3.1 Fonte

| Item | Valor |
|------|-------|
| Arquivo | `base_mfgarch_completa.xlsx` |
| Aba | `Sheet1` |
| Período | 05/01/1999 a 30/12/2025 |
| Observações diárias | 6.686 |
| Meses na covariável | 324 |

### 3.2 Variáveis

| Papel | Coluna | Descrição |
|-------|--------|-----------|
| Dependente | `ret_ibov` | Retorno diário do IBOV |
| Independente | `log_gpr_global` | Logaritmo do GPR Global (mensal) |
| Data | `date` | Data diária |
| Agregação mensal | `month` ou `year_month` | Chave para mapear dias → meses |

### 3.3 Tratamento de frequências mistas

A base é **diária**, mas `log_gpr_global` é constante dentro de cada mês. O script:

1. Agrupa por mês e extrai um valor mensal (`groupby(...).first()`).
2. Cria um índice inteiro `month_idx` para cada dia, apontando para o mês correspondente.
3. Na construção de \(\tau_t\), aplica defasagens **em meses**, não em dias.

```
Dia t  →  month_idx[t]  →  X mensal atual
         month_idx[t]-1  →  X defasado 1 mês
         ...
         month_idx[t]-K  →  X defasado K meses
```

Implementação: função `load_and_prepare()`.

### 3.4 Escala dos retornos

Os retornos são multiplicados por **100** antes da estimação (`SCALE_RETURNS = 100.0`), seguindo a prática do pacote `mfGARCH` em R para estabilidade numérica. As saídas em CSV e gráficos são **reconvertidas** à escala original (divisão por 100).

---

## 4. Fluxo de execução do script

```
main()
  │
  ├─► parse_args()              # argumentos de linha de comando
  │
  ├─► load_and_prepare()        # leitura Excel + preparação de frequências
  │
  ├─► fit_garch_midas()         # estimação por MLE (L-BFGS-B)
  │     ├─► negative_log_likelihood()
  │     │     ├─► beta_weights()
  │     │     ├─► midas_tau()
  │     │     └─► garch_short_term()
  │     └─► retorna GarchMidasResult
  │
  ├─► print_summary()           # resumo no terminal
  │
  └─► save_outputs()            # JSON, CSV e gráficos PNG
```

---

## 5. Detalhamento das funções

### 5.1 `load_and_prepare()`

**Entrada:** caminho do Excel, aba, nomes das variáveis.

**Processamento:**

1. Lê a planilha com `pandas.read_excel`.
2. Converte `date` para `datetime` e ordena cronologicamente.
3. Remove linhas com `NaN` em `ret_ibov` ou `log_gpr_global`.
4. Multiplica `ret_ibov` por 100.
5. Define chave mensal (`month`, `year_month` ou derivada de `date`).
6. Agrega `log_gpr_global` em série mensal.
7. Mapeia cada dia para índice mensal.

**Saída:**

| Objeto | Tipo | Uso |
|--------|------|-----|
| `returns` | `np.ndarray` | Retornos escalados |
| `x_monthly` | `np.ndarray` | Covariável mensal |
| `month_idx` | `np.ndarray` | Índice do mês para cada dia |
| `dates` | `DatetimeIndex` | Datas diárias |
| `monthly_series` | `pd.Series` | Série mensal para exportação |

### 5.2 `beta_weights(k, w1, w2)`

Calcula o vetor normalizado \(\phi_1, \ldots, \phi_K\).

- **Restrito:** `w1=1.0`, `w2` estimado.
- **Não restrito:** `w1` e `w2` estimados (flag `--pesos-nao-restritos`).

### 5.3 `midas_tau(x_monthly, month_idx_daily, m, theta, weights)`

Para cada dia \(t\):

\[
\log(\tau_t) = m + \theta \sum_{k=0}^{K-1} w_k \cdot X_{\text{month\_idx}[t] - (k+1)}
\]

Observações iniciais com defasagem negativa recebem contribuição zero. O resultado é limitado inferiormente em \(10^{-12}\) para evitar divisão por zero no GARCH.

### 5.4 `garch_short_term(returns, tau, mu, alpha, beta)`

Recursão do componente \(g_t\) a partir de \(t = 2\), usando \(\tau_{t-1}\) na equação GARCH.

### 5.5 `negative_log_likelihood(params, ...)`

Função-objetivo da otimização:

1. Extrai parâmetros e valida restrições (\(\alpha, \beta \geq 0\), \(\alpha+\beta < 1\), \(\omega > 0\)).
2. Calcula \(\tau_t\), \(g_t\), \(\sigma_t^2\).
3. Retorna \(-\mathcal{L}\); retorna `1e12` se restrições violadas.

### 5.6 `fit_garch_midas()`

**Método:** `scipy.optimize.minimize` com algoritmo **L-BFGS-B** (suporta bounds).

**Parâmetros estimados (padrão restrito):**

| Parâmetro | Chave no JSON | Bound |
|-----------|--------------|-------|
| Média | `mu` | livre |
| GARCH α | `alpha` | (0, 0.999) |
| GARCH β | `beta` | (0, 0.999) |
| Intercepto MIDAS | `m` | livre |
| Efeito GPR | `theta` | livre |
| Peso Beta ω₂ | `w2` | (0.0001, 50) |

**Valores iniciais:**

```python
mu0  = média dos retornos
var0 = variância dos retornos
x0   = [mu0, 0.05, 0.90, log(var0), -0.01, 5.0]
```

**Critérios de ajuste:**

\[
\text{AIC} = 2p - 2\ln\mathcal{L}, \qquad \text{BIC} = p\ln T - 2\ln\mathcal{L}
\]

onde \(p\) = número de parâmetros livres e \(T\) = número de observações.

### 5.7 `save_outputs()`

Gera o diretório de saída (padrão: `resultados_garch_midas/`) com:

| Arquivo | Conteúdo |
|---------|----------|
| `garch_midas_resultados.json` | Parâmetros, AIC, BIC, convergência |
| `garch_midas_series.csv` | Retornos, \(\sigma_t^2\), \(\tau_t\), \(g_t\), resíduos |
| `covariavel_mensal.csv` | Série mensal de `log_gpr_global` |
| `volatilidade_decomposicao.png` | Gráfico de \(\sqrt{\sigma^2}\), \(\sqrt{g}\), \(\sqrt{\tau}\) |
| `residuos_padronizados.png` | Série de \(\varepsilon_t\) |

---

## 6. Parâmetros de linha de comando

```bash
python garch_midas_ibov_gpr.py [opções]
```

| Argumento | Padrão | Descrição |
|-----------|--------|-----------|
| `--arquivo` | `base_mfgarch_completa.xlsx` | Caminho do Excel |
| `--aba` | `Sheet1` | Nome da aba |
| `--k` | `12` | Lags MIDAS mensais |
| `--saida` | `resultados_garch_midas` | Diretório de saída |
| `--pesos-nao-restritos` | desligado | Estima ω₁ e ω₂ livremente |

**Exemplo:**

```bash
python garch_midas_ibov_gpr.py --k 24 --saida resultados_k24
```

---

## 7. Resultados da estimação (K = 12)

Estimativa obtida com a configuração padrão:

| Parâmetro | Valor estimado |
|-----------|----------------|
| \(\mu\) | 0,0621 |
| \(\alpha\) | 0,0727 |
| \(\beta\) | 0,9111 |
| \(\alpha + \beta\) | 0,9837 |
| \(m\) | 4,3399 |
| \(\theta\) | **−0,7255** |
| \(\omega_2\) | 5,0034 |
| \(K\) | 12 |

| Critério | Valor |
|----------|-------|
| Log-verossimilhança | −12.283,58 |
| AIC | 24.579,16 |
| BIC | 24.620,01 |
| Convergência | Sim |

**Interpretação econômica de \(\theta < 0\):** aumentos em `log_gpr_global` (com defasagens MIDAS de até 12 meses) associam-se a **redução** da volatilidade de longo prazo do IBOV.

A proporção média \(\bar{\tau}/\bar{\sigma^2} \approx 0{,}98\) indica que o componente de longo prazo domina a variância condicional nesta especificação.

---

## 8. Significância estatística de \(\theta\)

Inferência complementar (script `theta_significance.py`):

### Teste Wald (Hessiana numérica)

| Estatística | Valor |
|-------------|-------|
| \(\hat{\theta}\) | −0,7255 |
| Erro-padrão | 0,0837 |
| \(t\) | −8,66 |
| \(p\)-valor (bilateral) | \(\approx 9{,}6 \times 10^{-18}\) |

### Teste da razão de verossimilhança (H₀: \(\theta = 0\))

| Estatística | Valor |
|-------------|-------|
| LL irrestrito | −12.283,58 |
| LL restrito (\(\theta=0\)) | −12.307,01 |
| LR | 46,87 |
| \(p\)-valor (\(\chi^2_1\)) | \(\approx 7{,}6 \times 10^{-12}\) |

**Conclusão:** \(\theta\) é **altamente significativo** nos dois testes. O GPR Global exerce efeito estatisticamente relevante sobre \(\tau_t\).

---

## 9. Diagrama da decomposição

```mermaid
flowchart TD
    A[base_mfgarch_completa.xlsx] --> B[load_and_prepare]
    B --> C[ret_ibov diário x100]
    B --> D[log_gpr_global mensal]
    B --> E[month_idx: mapeamento dia-mês]

    C --> F[fit_garch_midas]
    D --> F
    E --> F

    F --> G[midas_tau: componente longo prazo τ_t]
    F --> H[garch_short_term: componente curto prazo g_t]

    G --> I["σ²_t = g_t × τ_t"]
    H --> I

    I --> J[Máxima Verossimilhança L-BFGS-B]
    J --> K[Parâmetros: μ, α, β, m, θ, ω₂]

    K --> L[save_outputs]
    L --> M[JSON + CSV + PNG]
```

---

## 10. Dependências

Arquivo `requirements.txt`:

```
pandas>=2.0.0
numpy>=1.24.0
scipy>=1.10.0
matplotlib>=3.7.0
openpyxl>=3.1.0
```

Instalação:

```bash
pip install -r requirements.txt
```

---

## 11. Limitações e extensões possíveis

| Aspecto | Situação atual | Extensão sugerida |
|---------|----------------|-------------------|
| Distribuição dos erros | Normal | Student-\(t\) para caudas pesadas |
| Inferência | Fora do script principal | Integrar EP, \(t\) e LR em `fit_garch_midas()` |
| Robustez | Um ponto inicial | `multi.start` com vários `x0` |
| Covariáveis | Uma (`log_gpr_global`) | GARCH-MIDAS com duas covariáveis |
| Previsão | Não implementada | Função `forecast()` out-of-sample |

---

## 12. Estrutura de arquivos do projeto

```
mestrado_gpr/
├── base_mfgarch_completa.xlsx      # dados de entrada
├── garch_midas_ibov_gpr.py         # script principal
├── theta_significance.py           # inferência de θ (complementar)
├── requirements.txt
├── GARCH_MIDAS_DETALHAMENTO.md   # este documento
└── resultados_garch_midas/
    ├── garch_midas_resultados.json
    ├── garch_midas_series.csv
    ├── covariavel_mensal.csv
    ├── volatilidade_decomposicao.png
    └── residuos_padronizados.png
```

---

*Documento gerado com base na implementação em `garch_midas_ibov_gpr.py` e na estimação com K = 12.*
